<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
	<meta name="generator" content="Jekyll v3.8.5">
	<title><?= isset($title) ? $title : 'CIShop' ?> - Codeigniter E-Commerce</title>

	<link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/navbar-fixed/">

	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/libs/bootstrap/css/bootstrap.min.css">
	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/libs/fontawesome/css/all.min.css">
	<!-- Custom styles for this template -->
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/CSS/style/main.css">
</head>

<body>

	<!-- Navbar -->
	<?php $this->load->view('layouts/_navbar'); ?>
	<!-- Endnavbar -->

	<!-- Content -->
	<?php $this->load->view($page); ?>
	<!-- End Content -->

	<?php $this->load->view('layouts/footer'); ?>

	<script type="text/javascript" src="<?php echo base_url(); ?>assets/libs/jquery/jquery.slim.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	<script>
		AOS.init();
	</script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/navbar-scroll.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>
</body>

</html>