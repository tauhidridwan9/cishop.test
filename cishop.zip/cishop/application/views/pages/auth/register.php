<div class="page-content page-auth mt-100" id="register">
	<?php $this->load->view('layouts/_alert') ?>
	<div class="section-store-auth" data-aos="fade-up">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-4">
					<h2>
						Formulir Pendaftaran
					</h2>
					<?= form_open('register', ['method' => 'POST']) ?>
					<form class="mt-3">
						<div class="form-group">
							<label for="">Nama</label>
							<?= form_input('name', $input->name, ['class' => 'form-control', 'required' => true, 'autofocus' => true]) ?>
							<?= form_error('name') ?>
						</div>
						<div class="form-group">
							<label for="">E-Mail</label>
							<?= form_input(['type' => 'email', 'name' => 'email', 'value' => $input->email, 'class' => 'form-control', 'placeholder' => 'Masukkan alamat email aktif', 'required' => true]) ?>
							<?= form_error('email') ?>
						</div>
						<div class="form-group">
							<label for="">Password</label>
							<?= form_password('password', '', ['class' => 'form-control', 'placeholder' => 'Masukkan password minimal 8 karakter', 'required' => true]) ?>
							<?= form_error('password') ?>
						</div>
						<div class="form-group">
							<label for="">Konfirmasi Password</label>
							<?= form_password('password_confirmation', '', ['class' => 'form-control', 'placeholder' => 'Masukkan password yang sama', 'required' => true]) ?>
							<?= form_error('password_confirmation') ?>
						</div>
						<button type="submit" class="btn btn-primary">Register</button>

				</div>
			</form>
		</div>
		<?= form_close() ?>
		</div>
	</div>
</div>
</div>