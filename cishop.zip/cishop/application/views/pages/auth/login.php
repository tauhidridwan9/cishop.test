<div class="page-content page-auth">
	<?php $this->load->view('layouts/_alert') ?>
	<div class="section-store-auth" data-aos="fade-up">
		<div class="container">
			<div class="row align-items-center row-login">
				<div class="col-lg-6 text-center">
					<img src="/images/login-placeholder.png" alt="" class="w-50 mb-4 mb-lg-none" />
				</div>
				<div class="col-lg-5">
					<h2>
						Belanja kebutuhan utama, <br />
						menjadi lebih mudah
					</h2>
					<?= form_open('login', ['method' => 'POST']) ?>
					<form class="mt-3">
						<div class="form-group">
							<label for="">E-Mail</label>
							<?= form_input(['type' => 'email', 'name' => 'email', 'value' => $input->email, 'class' => 'form-control', 'placeholder' => 'Masukkan alamat email', 'required' => true]) ?>
							<?= form_error('email') ?>
							<div class="form-group">
								<label for="">Password</label>
								<?= form_password('password', '', ['class' => 'form-control', 'placeholder' => 'Masukkan password', 'required' => true]) ?>
								<?= form_error('password') ?>
							</div>
							<button type="submit" class="btn btn-primary">Login</button>
						</form>
						<?= form_close() ?>
				</div>
			</div>
		</div>
	</div>
</div>
