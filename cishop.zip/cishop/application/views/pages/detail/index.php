<div class="page-content page-details">
    <section class="store-breadcrumbs" data-aos="fade-down" data-aos-delay="100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Product Details
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <section class="store-gallery" id="gallery">
        <div class="container">
            <div class="row">
                <div class="col-lg-8" data-aos="zoom-in">
                    <img src="<?= $content->image ? base_url("/images/product/$content->image") : base_url("/images/product/default.png") ?>" />
                </div>
            </div>
    </section>
    <div class="store-details-container" data-aos="fade-up">
        <section class="store-heading">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <h1><?= $content->title ?></h1>
                        <div class="price"><strong>Rp<?= number_format($content->price, 0, ',', '.') ?>,-</strong></div>
                        <div class="description" data-aos="zoom-in">
                        <p>
                            <?= $content->description ?>
                        </p>
                    </div>
                </div>
                < </div>
            </div>
        </section>
        <section class="store-description">
            <div class="container">
                <div class="row">
                    <div class="col-8 col-lg-4" data-aos="zoom-in">
                        <form action=" <?= base_url("/cart/add") ?>" method="POST">
                            <input type="hidden" name="id_product" value="<?= $content->id ?>">
                            <div class="input-group">
                                <input type="number" name="qty" value="1" class="form-control">
                                <div class="input-group-append">
                                    <button class="btn btn-success">Add to Cart</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </section>
    </div>
</div>