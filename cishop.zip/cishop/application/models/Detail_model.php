<?php

defined('BASEPATH') or exit('No direct script access allowed');

    class Detail_model extends MY_Model
{

    protected $table = 'product';

    public function getDefaultValues()
    {
        return [
            'title'         => '',
            'price'        => '',
            'image'        => '',
            'slug'          => '',
            'id_category'   => '',
            'is_available' => '',
            'description'   =>''
        ];
    }


}
