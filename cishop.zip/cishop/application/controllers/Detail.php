<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Detail extends MY_Controller
{



        public function __construct()
        {
                parent::__construct();
                $this->id  = $this->session->userdata('id');
        }



        public function index($id)
        {
                $data['title']                = 'Detail';
                $data['content']        = $this->detail->where('id',$id)->first();
                $data['page']                = 'pages/detail/index';

                return $this->view($data);
        }
      
}


/* End of file Detail.php */
